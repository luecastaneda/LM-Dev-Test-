
create schema lm_auth_svc;


create table lm_auth_svc.detalle_user_estado(
det_id_estado serial primary key,
det_estado char(1)
);

CREATE TABLE lm_auth_svc.usuario_auth (
	usuario_id serial NOT NULL,
	username varchar(20) NULL,
	user_password varchar(200) NULL,
	det_id_estado int4 NULL,
	CONSTRAINT usuario_auth_pkey PRIMARY KEY (usuario_id),
	CONSTRAINT usuario_auth_det_id_estado_fkey FOREIGN KEY (det_id_estado) REFERENCES lm_auth_svc.detalle_user_estado(det_id_estado)
)
WITH (
	OIDS=FALSE
) ;
